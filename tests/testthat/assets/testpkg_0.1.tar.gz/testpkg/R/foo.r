#' A dummy square function
#'
#' @param x [\code{numeric}]\cr
#'  Numbers to square.
#' @return Squared numbers.
#' @export
foo = function(x) x*x
