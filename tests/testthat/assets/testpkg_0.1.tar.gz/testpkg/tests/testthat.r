library(testthat)
library(testpkg)
test_check("testpkg")
