context("foo")

test_that("foo works", {
  expect_equal(foo(2), 4)
})
